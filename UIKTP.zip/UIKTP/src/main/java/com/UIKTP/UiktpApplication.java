package com.UIKTP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UiktpApplication {

	public static void main(String[] args) {
		SpringApplication.run(UiktpApplication.class, args);
	}

}
