package com.UIKTP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UiktpApplicationTests {

	@Test
	void contextLoads() {
	}

}
