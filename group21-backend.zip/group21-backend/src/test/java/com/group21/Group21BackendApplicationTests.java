package com.group21;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Group21BackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
