package com.group21;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Group21BackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(Group21BackendApplication.class, args);
	}

}
